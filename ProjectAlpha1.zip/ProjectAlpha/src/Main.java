import java.util.Scanner;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Main {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        //This will get the students name and let them choose to view old or new grades.
        Scanner userInput = new Scanner(System.in);
        System.out.println("Please enter your name.");
        String studentName = userInput.nextLine();
        System.out.println("What class are you checking or submitting grades for?");
        String classForGrades = userInput.nextLine();
        System.out.println("Enter Old to access old grades, enter New to submit new grades.");
        String oldOrNewOption = userInput.nextLine();
        System.out.println(oldOrNewOption);
        switch (oldOrNewOption.toLowerCase()) {
            case "old":
                System.out.println("Switch works for old");
                //Will search text file using classForGrades string and the string "End"
                // and output the grades from the text file
                break;
            case "new":
                System.out.println("Switch works for new");
                //For new grades the student will select which type of grade they are submitting.
                while (oldOrNewOption.toLowerCase().equals("new")) {

                    System.out.println("Are you submitting quizzes, homework, exams, or project grades? Please enter" +
                            " the name of the type of grade (ex. quizzes)");
                    Scanner userInput1 = new Scanner(System.in);
                    String gradeTypeBeingInput = userInput.nextLine();
                    switch (gradeTypeBeingInput.toLowerCase()) {
                        case "quizzes":
                            System.out.println("How many grades would you like to enter?");
                            int numberGradesBeingEntered = userInput.nextInt();
                            //This int will be used in the switch cases to stop the for loop on number of grades being input
                            System.out.println("Enter exit if you made a mistake and would like to re try the program.");
                            String exitOption = userInput.nextLine();
                            if (exitOption.toLowerCase().equals("exit")) {

                                System.out.println("The program will now close.");
                            } else {
                                System.out.println("Input your grades one at a time.");
                                ObjectOutputStream grades = new ObjectOutputStream(new FileOutputStream("Grades.txt"));


                                for (int i = 0; i < numberGradesBeingEntered; i++) {
                                    //I will be using class strings and the word End to separate the differences
                                    // between grade types to find average

                                    grades.writeObject(classForGrades);
                                    grades.writeObject(userInput.nextLine());
                                }
                                    grades.writeObject("End");

                                System.out.println("Type new if you would like to continue adding new grades or anything else to exit.");

                                oldOrNewOption = userInput.nextLine();
                                break;
                            }

                        case "homework":
                            System.out.println("How many grades would you like to enter?");

                            System.out.println("Enter exit if you made a mistake and would like to re try the program.");
                            String exitOption1 = userInput.nextLine();
                            if (exitOption1.toLowerCase().equals("exit")) {
                                System.out.println("The program will now close.");
                            } else {
                                System.out.println("Input your grades one at a time.");
                                ObjectOutputStream grades = new ObjectOutputStream(new FileOutputStream("Grades.txt"));
                                int numberGradesBeingEntered1 = userInput.nextInt();
                                for (int i = 0; i < numberGradesBeingEntered1; i++) {

                                    grades.writeObject(classForGrades);
                                    grades.writeObject(userInput.nextLine());
                                }
                                System.out.println("Type new if you would like to continue adding new grades or anything else to exit.");

                                oldOrNewOption = userInput.nextLine();

                                break;
                            }


                        case "exams":
                            System.out.println("How many grades would you like to enter?");

                            System.out.println("Enter exit if you made a mistake and would like to re try the program.");
                            String exitOption2 = userInput.nextLine();
                            if (exitOption2.toLowerCase().equals("exit")) {
                                System.out.println("The program will now close.");
                            } else {
                                System.out.println("Input your grades one at a time.");
                                int numberGradesBeingEntered2 = userInput.nextInt();
                                ObjectOutputStream grades = new ObjectOutputStream(new FileOutputStream("Grades.txt"));
                                for (int i = 0; i < numberGradesBeingEntered2; i++) {

                                    grades.writeObject(classForGrades);
                                    grades.writeObject(userInput.nextLine());
                                }
                                System.out.println("Type new if you would like to continue adding new grades or anything else to exit.");

                                oldOrNewOption = userInput.nextLine();
                                break;
                            }

                        case "project": case "projects":
                            System.out.println("How many grades would you like to enter?");

                            System.out.println("Enter exit if you made a mistake and would like to re try the program.");
                            String exitOption3 = userInput.nextLine();
                            if (exitOption3.toLowerCase().equals("exit")) {
                                System.out.println("The program will now close.");
                            } else {
                                System.out.println("Input your grades one at a time.");
                                ObjectOutputStream grades = new ObjectOutputStream(new FileOutputStream("Grades.txt"));
                                int numberGradesBeingEntered3 = userInput.nextInt();
                                for (int i = 0; i < numberGradesBeingEntered3; i++) {
                                    ObjectOutputStream projectGrades = new ObjectOutputStream(new FileOutputStream("Grades.txt"));
                                    grades.writeObject(classForGrades);
                                    grades.writeObject(userInput.nextLine());
                                }
                                System.out.println("Type new if you would like to continue adding new grades, " +
                                        "or anything else to exit.");

                                oldOrNewOption = userInput.nextLine();
                                break;
                            }


                            }


                    }
                System.out.println("Enter the class you would like to see your average grade for.");
                        String classOfAverageGrade = userInput.nextLine();
                        switch (classOfAverageGrade.toLowerCase()) {
                            case "class1": // code to get grades and find average using string of class name
                                           // in text file and end to separate grades. Confused how to use the values in
                                           // the text file to find averages and do math calculations.
                                break;
                            case "class2":
                                break;
                            case "class3":
                                break;

                        }
                }
        }

    }


